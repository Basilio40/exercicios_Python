
resultado = (100/5 - 413/5)* (20/5 - (5*4)/5) 
print(int(resultado))