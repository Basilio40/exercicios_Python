raio = float(input('Informe o raio do circulo:  '))
area = raio**2 * 3.1416
print(f'A area do circulo é: {area:.1f}') 
