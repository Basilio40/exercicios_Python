ganhoH = float(input(f'Informe o valor ganho por hora:  '))
Htrab = float(input(f'Informe o total de horas trabalhadas mês:  '))
salario = ganhoH * Htrab
print('\o/'*15)
print(f'O salário do mês presente será : R$ {salario:.1f}')
print('\o/'*15)