num = int(input('Informe um numero: '))
num1 = num - 1
num2 = num + 1 
print(num)
print(f'O numero anterior é: {num1}')
print('O número posterior é:', num2)