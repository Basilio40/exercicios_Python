F = float(input(f'Informe a temperatura em Fahrenheit:  '))
C = (5*(F-32)/9)
print(f'A temperatura em °C é: {C}')