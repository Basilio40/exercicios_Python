cotaUSD = float(input('Informe a cotação do Dolar:  '))
val = float(input('Inserir o valor em R$: '))
valorReal = cotaUSD * val
print (f'O valor da conversão de dolar é R$',valorReal)