int1 = int(input(f'Informe o primeiro valor:  '))
int2 = int(input(f'Informe o segundo valor:  '))
real = float(input(f'Informe o valor real:  '))
prod = int1*2 + int2/2 
soma = int1*3 + real
cubo = real**3

print(f'O produto é : {prod:.1f}')
print(f'A soma é: {soma:.1f}')
print(f'O número elevado ao cubo é {cubo:.1f}')