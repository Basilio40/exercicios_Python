txt = str(input('Digite um texto:  ')).strip().upper()
contador = 0
for palavra in txt:
    for letra in palavra:
        if letra in 'AEIOU':
            contador += 1

print(f'Quantidade de vogais  {contador}')
print(f'total de espaços {txt.count(" ")}')
