ganhoH = float(input(f'Informe o valor ganho por hora:  '))
Htrab = float(input(f'Informe o total de horas trabalhadas mês:  '))
salarioBruto = ganhoH * Htrab
impRenda = salarioBruto * 0.11
inss = salarioBruto * 0.08
contSind = salarioBruto * 0.05
salarioLiq = salarioBruto - impRenda - inss - contSind
desc = impRenda + inss + contSind
print(f'O salário Bruto do mês presente será : R$ {salarioBruto}')
print(f'O valor do imposto de Renda é : R$ {impRenda}')
print(f'O valor do INSS é  : R$ {inss}')
print(f'O valor de Contribuição Sindical é  : R$ {contSind}')
print(f'O salário Liquido do mês presente será : R$ {salarioLiq}')
print(f'O valor de descontos serão : R$ {desc}')