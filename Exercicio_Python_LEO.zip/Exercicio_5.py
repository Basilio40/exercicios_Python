medida = float(input('Informe o valor em metros:  '))
converte = medida * 100
print('-='*30)
print(f'A conversão do valor é: {converte:.1f} centrimetros')
print('-='*30)