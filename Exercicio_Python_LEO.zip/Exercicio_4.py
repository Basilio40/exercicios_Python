bim1 = float(input('Informe a nota do primeiro bimestre:  '))
bim2 = float(input('Informe a nota do segundo bimestre:   '))
bim3 = float(input('Informe a nota do terceiro bimestre:  '))
bim4 = float(input('Informe a nota do primeiro bimestre:  '))
media = (bim1 + bim2 + bim3 + bim4)/ 4
print('~'*20)
print(f'A média dos bimestres é: {media:.1f}')
print('~'*20)
