txt = str(input('Informe a primeira string:  '))
txt1 = str(input('Informe a primeira string:  '))
mede1 = len(txt)
mede2 = len(txt1)
print(f'O comprimento de texto é: {mede1}')
print(f'O comprimento de texto é: {mede2}')
if txt == txt1:
    print('igual')
elif mede1 == mede2:
     print('tamanho igual conteudo diferente ')   
else:
    print('diferente')
