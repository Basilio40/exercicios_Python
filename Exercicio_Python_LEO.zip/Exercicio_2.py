num = int(input('Informe um número:  '))
print(f'O número informado foi: {num}')