frase = ('Python, é, muito, legal')
print(frase[0:6])
print(frase[11:16])
print(frase[18:23])