num1 = int(input('Informe o primeiro valor:  '))
num2 = int(input('Informe o segundo valor:   '))
soma = num1 + num2
print(f'A somatória dos valores é: {soma}')