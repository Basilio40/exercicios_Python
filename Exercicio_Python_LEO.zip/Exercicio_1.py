print('-='*20)
print('Olá Mundo !')
print('-='*20)